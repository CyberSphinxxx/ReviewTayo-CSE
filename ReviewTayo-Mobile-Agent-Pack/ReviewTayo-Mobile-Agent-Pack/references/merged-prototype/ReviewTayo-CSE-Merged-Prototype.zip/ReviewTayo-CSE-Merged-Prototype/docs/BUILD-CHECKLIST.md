# ReviewTayo CSE — Continuous Build Checklist

## Architecture
- [x] Frontend-only HTML/CSS/JS prototype
- [x] Direct `index.html` launch
- [x] Five-tab IA preserved
- [x] Light and dark themes share one layout
- [ ] Split larger feature logic further only if maintenance materially improves

## Theme
- [x] ReviewTayo light palette
- [x] Claude-inspired dark palette
- [x] Device / Light / Dark setting
- [ ] Audit all contrast in both themes
- [ ] Verify theme persistence if localStorage is later added

## Home
- [x] Claude-style hero
- [x] Smart Drill primary CTA
- [x] Daily Question
- [x] Review Due shortcut
- [x] Streak/progress ring
- [x] Contextual resume mock card
- [x] Settings access
- [ ] Visual QA at 320/375/390/430px

## Learn
- [x] Continue Learning
- [x] Quick Sheets
- [x] Subject progress
- [x] Study Guides row
- [ ] Build richer lesson prototype if requested

## Practice
- [x] Smart Drill
- [x] Weakest Area
- [x] Timed Practice
- [x] Mock Exam visible
- [x] Practice by Subject visible
- [x] More Practice
- [x] Random set
- [x] Build a Quiz
- [x] Mastery Rounds prototype
- [ ] Improve custom quiz subject/timing controls
- [ ] Add mock marking/revisit flow if required

## Review
- [x] Large Review Due count
- [x] Review Now
- [x] Again / Got It flashcards
- [x] Mistakes
- [x] Saved
- [x] Concepts to revisit
- [x] Review history
- [ ] Empty state QA when due count reaches zero

## Progress
- [x] Study Score
- [x] Trend line
- [x] Needs Attention action
- [x] Subject accuracy
- [x] CSE Journey
- [x] Weekly activity
- [x] Recent Mock
- [x] Mock result prototype
- [x] Next-7-days summary

## Quiz
- [x] Question flow
- [x] Correct / incorrect states
- [x] Explanations
- [x] Concept mastery badge
- [x] Try Another Like This
- [x] Review concept placeholder
- [x] Result / completion state
- [ ] Add saved-question toggle if needed

## Settings
- [x] Theme setting
- [x] Professional / Sub-Professional switch
- [x] Target date
- [x] Daily goal
- [x] Reminder placeholder
- [x] Run Onboarding Demo

## Onboarding
- [x] 8-step shell
- [x] Progress choice
- [x] CSE level
- [x] Starting point + date
- [x] Study days + session length
- [x] Daily goal
- [x] Plan review
- [x] Appearance + reminders
- [x] All Set
- [x] Commit into prototype state
- [ ] Replace browser `prompt()` custom goal with designed sheet
- [ ] Full keyboard/focus QA

## Responsive / Accessibility
- [x] Reduced-motion CSS
- [x] Semantic buttons for core controls
- [ ] Visual QA 320px
- [ ] Visual QA 360px
- [ ] Visual QA 375px
- [ ] Visual QA 390px
- [ ] Visual QA 430px
- [ ] Keyboard-only walkthrough
- [ ] Screen-reader labeling audit
- [ ] Contrast audit light theme
- [ ] Contrast audit dark theme

## Verification
- [x] JavaScript syntax check
- [x] Duplicate static ID check
- [ ] Browser runtime console check
- [ ] Full Home → Drill → Similar → Result flow
- [ ] Full Review Due flow
- [ ] Full Mock flow
- [ ] Full onboarding flow
- [ ] Theme switch flow
- [ ] Professional/Sub-Professional flow

## Final gate
Do not call this production-ready. It is a high-fidelity reference prototype.

Final loop report must include:
- `Checklist: X / Y completed`
- `Blocked: Z`
- `Verification: PASS / PARTIAL / FAIL`
