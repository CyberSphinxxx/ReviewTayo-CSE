# AGENTS.md — ReviewTayo CSE Prototype

## Mission
Continue refining the prototype until every required checklist item is either completed and verified or explicitly marked BLOCKED. Never silently skip a requirement.

## Product rules
1. Keep five top-level tabs: Learn, Practice, Home, Review, Progress.
2. Home answers “what should I do now?”
3. Learn teaches; Practice tests; Review revisits; Progress measures.
4. Keep complex intelligence under a simple interface.
5. Use progressive disclosure instead of exposing every mode.
6. Preserve Claude-inspired dark mode and ReviewTayo cream/maroon light mode.
7. Do not add XP, coins, hearts, leagues, social feeds, or AI chat.
8. Do not add a backend for prototype work.
9. Keep `index.html` directly openable from disk.
10. Do not claim completion without running the checklist.

## Coding loop
Repeat until complete:
1. Read `docs/BUILD-CHECKLIST.md`.
2. Pick the highest-priority unchecked item.
3. Inspect only relevant files first.
4. Implement the smallest coherent change.
5. Test it.
6. Mark the checklist only after verification.
7. Re-check for regressions.
8. Continue automatically.

If blocked, record: `BLOCKED:`, `Reason:`, and `What remains:` in the checklist and continue to the next task.
