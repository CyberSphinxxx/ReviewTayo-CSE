# ReviewTayo: CSE — Merged Reference Prototype

This is a frontend-only reference prototype that merges the Claude visual direction with the stronger ReviewTayo feature set.

## Run

Open `index.html` directly in a browser. No install or build step is required.

## Core direction

- Light mode keeps ReviewTayo's cream/maroon identity.
- Dark mode uses the Claude-inspired burgundy/near-black palette.
- Five tabs: Learn, Practice, Home, Review, Progress.
- Claude-style layouts are the visual foundation.
- Practice is expanded with Mock Exam, Practice by Subject and More Practice.
- Settings includes theme, exam level, exam date, goal and onboarding demo.
- Quiz, similar-question recovery, Review Due flashcards, mock flow, and onboarding are interactive local prototypes.

## Files

- `index.html` — markup and inline SVG mascot source
- `css/app.css` — visual system and screen styles
- `js/app.js` — local state and prototype interactions
- `AGENTS.md` — rules for coding agents
- `docs/BUILD-CHECKLIST.md` — loop completion checklist

No backend, database, authentication provider, or build tooling is included.
